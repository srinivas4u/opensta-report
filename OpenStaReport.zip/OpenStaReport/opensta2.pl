#!/usr/bin/perl

#&HttpStat_Data;
# Collecting Datas From Audit log For Time Consuming URL`s
sub Audit_Data
{

open (Audit,"<Audit.txt");


while (<Audit>)

	{

	@AuditTmp = split(/,,,,/);
	push @AuditAOA, [@AuditTmp];
$AuditTotal=scalar(@AuditAOA);

	}

# Accessing and Printing the array

print "Extract the Timers.txt and Aduit.txt form OpenSTA TEST.\n";
print "Enter the name/version of Report:";
$out=<stdin>;
chomp($out);

open (OUTRES,">C:/Perl64/bin/OpenStaReport/Results.txt");
open (OUTRES1,">C:/Perl64/bin/OpenStaReport/Results.xls");


#html template

$start_Time = $AuditAOA[2][0];
$end_time = $AuditAOA[$AuditTotal-1][0];
$period = $start_Time."-".$end_time."\n";
$end_time1 = $end_time ;
 chop($end_time1);
 chop($end_time1);
$end_time1 =~s/ (.*?):(.*?):(.*?)//sgmi;

print "Date :" .$end_time1."\n";
print "Period :" .$period ;
print "Start Time :".$start_Time."\n";
print "End Time :".$end_time."\n";

}
&Audit_Data;



open (F, "Timers.txt") || die "Could not open database: $:";

%timername_index = ();

sub print_all_entries_for_timername {
    foreach $timername(sort keys %timername_index) {

	print_entries_for_timername($timername);

    }
}

while ($line = <F>) {
    chomp $line;
 ($testsname, $userid, $sname ,$timername ,$activeuser, $elapsedtime,$enddate,$endtime) = split (/,,/, $line);
    create_entry($testsname, $userid, $sname ,$timername ,$activeuser, $elapsedtime,$enddate,$endtime);
}

sub create_entry {             # create_entry (timername, category, name)
    my($testsname, $userid, $sname ,$timername ,$activeuser, $elapsedtime,$enddate,$endtime) = @_;
    # Create an anonymous array for each entry
    $rlEntry = [$testsname, $userid, $sname ,$timername ,$activeuser, $elapsedtime,$enddate,$endtime];
    # Add this to the two indices
    push (@{$timername_index {$timername}}, $rlEntry);         # By timername


} 
      
#print OUTRES "SCRIPT,,TIMER NAME,,MIN,,MAX,,AVG,,NUMOFUSERS\n";


sub print_entries_for_timername {
    my($timername) = @_;

    foreach  $rlEntry (@{$timername_index{$timername}}){

		
$i++;
push @list,$rlEntry->[5];
push @name,$rlEntry->[2];
push @uid,$rlEntry->[1];
print  "$rlEntry->[2]\t$rlEntry->[3]\t$rlEntry->[5]\n";

	}


@tuser = @uid; 
$tu = scalar (@uid);
@uid1 = sort  by_uid (@uid);
$to = scalar(@list);

@trans = sort  by_name (@name);


print OUTRES "$trans[0],,$timername,,";

print OUTRES1 "$trans[0]\t$timername\t";

@sorted = sort by_number (@list);

$y = scalar(@list);
if ($sorted[0] == "Null") {


	$first = $sorted[1];
print OUTRES "0.000000,,";
print OUTRES1 "0.000000\t";

}
if ($sorted[0] != "Null") {

     print OUTRES "$sorted[0],,";
	 print OUTRES1 "$sorted[0]\t";
}
	 print OUTRES "$sorted[$y-1],,";
 print OUTRES1 "$sorted[$y-1]\t";

sub by_number {
   $a <=> $b;
}
sub by_name {
   $a <=> $b;
}
sub by_uid {
   $a <=> $b;
}

$y2=$tal;
$y3=$i;
$avg = (($sorted[0]+$sorted[$y-1])/2);
$avg1 = $avg;

###############################


# min and max calculaion


print OUTRES "$avg1,,$to\n";
print OUTRES1 "$avg1\t$to\n";

  undef ($rlEntry->[5]);
  undef ($tal);
  undef($y);
  undef ($i);

undef (@list);

undef (@name);
undef (@uid);
undef (@uid1);


	}

&print_all_entries_for_timername;


close (F);
close (OUTRES);
close (OUTRES1);

open (OUTR,">C:\\Perl64\\bin\\OpenStaReport\\Template\\$out.html");

###############Template###################33


print OUTR <<START;
<html>
<link href="E:/Report/Template/Properties.css" rel="stylesheet" media="screen">
<link href="E:/Report/Template/adv_properties.css" rel="stylesheet" media="screen">

<head>
<title>Analysis Summary Report</title>
<META HTTP-EQUIV="Expires" CONTENT="0">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
</head>
<body class="main" bgcolor="#ffffff" topmargin=0 oncontextmenu="javascript:return false;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="sp_10px_row"></td>
			</tr>
		</table>
<table style = " background-color: #ffffff;" cols="2" width="800" height="20" border="0" borderColorDark="black" cellPadding="0" cellSpacing="0" borderColor="black"  >
      <tr>
        <td width="40"><img src="E:/Report/Template/PageHeaderBullet_trans.gif" alt="" WIDTH="40" HEIGHT="34"></td>
        <td class="header_page">&nbsp;Analysis Summary</td>
        <td class="header_timerange">Period: $period</td>
      </tr>
</table> 
<table style = "margin-left: 30;" height="20" summary="Analysis summary table"  >
	<br>
      <tr height="5" >
        <td class="text_em">Start Time:</td>
        <td headers="LraScenarioName" class="VerBl8">$start_Time</td>
      </tr>

      <tr>
        <td align="left" ><span class="Verbl8"><b>End Time:</b></td>
        <td headers="LraResultsInSession" class="VerBl8">$end_time</td>
      </tr>

      <tr>
        <td class="text_em">Date:</td>
        <td headers="LraDuration" class="VerBl8">$end_time1</td>
      </tr>
</table> 
  <br>



<table style = "margin-left: 17; background-color: #A9B2C5;" cols="1" width="750" height="22" border="0" cellPadding="0" cellSpacing="0"  >
      <tr>
        <td class="Verdana2Bold">&nbsp;Transaction Summary&nbsp;</td>
      </tr>
</table> 
<br>
START
open (FRONT, "<Results.txt") || die "Could not open results.txt: $:";
%timer_index = ();

sub print_all_entries_for_timer {
    foreach $timer(sort keys %timer_index) {

	print_entries_for_timername($timer);

    }
}
&print_all_entries_for_timer;
while ($liner = <FRONT>) {
    chomp $liner;
 ($scrname, $timernam, $mintim ,$maxtim ,$restim, $usrnam) = split (/,,/, $liner);
    create_en($scrname, $timernam, $mintim ,$maxtim ,$restim, $usrnam);
}

sub create_en{             # create_entry (timername, category, name)
    my($scrname, $timernam, $mintim ,$maxtim ,$restim, $usrnam) = @_;
    # Create an anonymous array for each entry
    $Entry = [$scrname, $timernam, $mintim ,$maxtim ,$restim, $usrnam];
    # Add this to the two indices
    push (@{$timer_index {$scrname}}, $Entry);         # By timername


} 
print OUTR <<TRANS;
<table style = "margin-left: 17; background-color: ffffff;" width="750" border="0" cellPadding="0" cellSpacing="0" summary="Transactions statistics summary table"  >
      <tr bgcolor="330066">
        <td id="LraTransaction Name" class="table_header" vAlign="top" width="150"><span class="Verdana2">Transaction Name</span></td>
        <td id="LraMinimum" class="table_header" vAlign="top" width="150"><span class="Verdana2">Timer Name</span></td>
        <td id="LraAverage" class="table_header" vAlign="top" width="150"><span class="Verdana2">Minimum</span></td>
        <td id="LraMaximum" class="table_header" vAlign="top" width="150"><span class="Verdana2">Maximum</span></td>
        <td id="LraStd. Deviation" class="table_header" vAlign="top" width="150"><span class="Verdana2">Average</span></td>
        <td id="Lra90 Percent" class="table_header" vAlign="top" width="150"><span class="Verdana2">Number of Users</span></td>
        <td id="LraPass" class="table_header" vAlign="top" width="150"><span class="Verdana2">id</span></td>
        <td id="LraFail" class="table_header" vAlign="top" width="150"><span class="Verdana2">Users</span></td>
        <td id="LraStop" class="table_header" vAlign="top" width="150"><span class="Verdana2">Comments</span></td>
      </tr>
TRANS

sub print_entries_for_timer {
    my($scrname) = @_;

    foreach  $Entry  (@{$timer_index{$scrname}}){

#print $Entry->[0]."\t".$Entry->[1]."\t".$Entry->[2]."\t".$Entry->[3]."\t".$Entry->[4]."\t".$Entry->[5]."\t".$Entry->[6]."\n";



print OUTR "<tr class=\"tabledata_lightrow\"><td headers=\"LraTransaction Name\"><b>$Entry->[0]</b></td>";
 print OUTR      "<td headers=\"LraMinimum\">        <span class=\"VerBl8\"><b>$Entry->[1]<b></td>";
     print OUTR   "<td headers=\"LraAverage\">        <span class=\"VerBl8\">$Entry->[2]</td>";
    print OUTR   "<td headers=\"LraAverage\">        <span class=\"VerBl8\">$Entry->[3]</td>";
    print OUTR   "<td headers=\"LraAverage\">        <span class=\"VerBl8\">$Entry->[4]</td>";

 print OUTR   "<td headers=\"LraAverage\">        <span class=\"VerBl8\">$Entry->[5]</td>";

#print $Entry->[0]."\t".$Entry->[1]."\n";

	}
}

&print_all_entries_for_timer;

sub print_all_entries_for_timer {
    foreach $scrname(sort keys  %timer_index) {

		     print_entries_for_timer($scrname);

    }
}
print OUTR <<HTTP;


</tr><tr><td class="tabledata_end" headers="LraTransaction Name" colspan="9"><img src="E:/Report/Template/dot_trans.gif" alt="" height="1" width="1" border="0"></td>
      </tr>

</table> 
  <br>

<table style = "margin-left: 17; background-color: #A9B2C5;" cols="1" width="750" height="22" border="0" cellPadding="0" cellSpacing="0"  >
      <tr>
        <td class="Verdana2Bold"></td>
      </tr>
</table> 
  <br>


</body></html>
HTTP

close (OUTR);
close (FRONT);